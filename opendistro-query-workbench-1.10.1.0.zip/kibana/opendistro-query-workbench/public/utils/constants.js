"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MESSAGE_TAB_LABEL = exports.TAB_CONTAINER_ID = exports.SMALL_COLUMN_WIDTH = exports.COLUMN_WIDTH = exports.PAGE_OPTIONS = exports.DEFAULT_NUM_RECORDS_PER_PAGE = void 0;

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
// Table constants
var DEFAULT_NUM_RECORDS_PER_PAGE = 10;
exports.DEFAULT_NUM_RECORDS_PER_PAGE = DEFAULT_NUM_RECORDS_PER_PAGE;
var PAGE_OPTIONS = [10, 20, 50, 100];
exports.PAGE_OPTIONS = PAGE_OPTIONS;
var COLUMN_WIDTH = '155px';
exports.COLUMN_WIDTH = COLUMN_WIDTH;
var SMALL_COLUMN_WIDTH = '60px'; // Tabs constants

exports.SMALL_COLUMN_WIDTH = SMALL_COLUMN_WIDTH;
var TAB_CONTAINER_ID = 'tabsContainer';
exports.TAB_CONTAINER_ID = TAB_CONTAINER_ID;
var MESSAGE_TAB_LABEL = 'Messages';
exports.MESSAGE_TAB_LABEL = MESSAGE_TAB_LABEL;
"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _eui = require("@elastic/eui");

var _utils = require("../../utils/utils");

require("../../ace-themes/sql_console");

var _constants = require("../../utils/constants");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var DoubleScrollbar = require('react-double-scrollbar');

var QueryResultsBody = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(QueryResultsBody, _React$Component);

  var _super = _createSuper(QueryResultsBody);

  function QueryResultsBody(props) {
    var _this;

    (0, _classCallCheck2.default)(this, QueryResultsBody);
    _this = _super.call(this, props);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "items", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "columns", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "panels", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "expandedRowColSpan", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onDownloadJSON", function () {
      if (!_this.props.queryResultsJSON) {
        _this.props.getJson(_this.props.queries);
      }

      setTimeout(function () {
        var jsonObject = JSON.parse(_this.props.queryResultsJSON);
        var data = JSON.stringify(jsonObject, undefined, 4);
        (0, _utils.onDownloadFile)(data, "json", _this.props.selectedTabName + ".json");
      }, 2000);
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onDownloadJDBC", function () {
      if (!_this.props.queryResultsJDBC) {
        _this.props.getJdbc(_this.props.queries);
      }

      setTimeout(function () {
        var jsonObject = JSON.parse(_this.props.queryResultsJDBC);
        var data = JSON.stringify(jsonObject, undefined, 4);
        (0, _utils.onDownloadFile)(data, "json", _this.props.selectedTabName + ".json");
      }, 2000);
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onDownloadCSV", function () {
      if (!_this.props.queryResultsCSV) {
        _this.props.getCsv(_this.props.queries);
      }

      setTimeout(function () {
        var data = _this.props.queryResultsCSV;
        (0, _utils.onDownloadFile)(data, "csv", _this.props.selectedTabName + ".csv");
      }, 2000);
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onDownloadText", function () {
      if (!_this.props.queryResultsTEXT) {
        _this.props.getText(_this.props.queries);
      }

      setTimeout(function () {
        var data = _this.props.queryResultsTEXT;
        (0, _utils.onDownloadFile)(data, "plain", _this.props.selectedTabName + ".txt");
      }, 2000);
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onDownloadButtonClick", function () {
      _this.setState(function (prevState) {
        return {
          isDownloadPopoverOpen: !prevState.isDownloadPopoverOpen
        };
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "closeDownloadPopover", function () {
      _this.setState({
        isDownloadPopoverOpen: false
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "toggleNodeData", function (node, expandedRowMap) {
      var newItemIdToExpandedRowMap = expandedRowMap;
      var rootNode = (0, _utils.findRootNode)(node, expandedRowMap);

      if (expandedRowMap[node.nodeId] && expandedRowMap[node.nodeId].expandedRow) {
        delete newItemIdToExpandedRowMap[node.nodeId].expandedRow;
      } else if (node.children && node.children.length > 0) {
        newItemIdToExpandedRowMap = _this.updateExpandedRow(node, expandedRowMap);
      }

      if (rootNode !== node) {
        newItemIdToExpandedRowMap = _this.updateExpandedRow(rootNode, expandedRowMap);
      }

      _this.props.updateExpandedMap(newItemIdToExpandedRowMap);
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "createItem", function (expandedRowMap, node, name) {
      var items = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      var nodeId = node.nodeId;
      var isSelected = false;

      if (!(0, _utils.isEmpty)(node.parent)) {
        isSelected = expandedRowMap[node.parent.nodeId] && expandedRowMap[node.parent.nodeId].selectedNodes && expandedRowMap[node.parent.nodeId].selectedNodes.hasOwnProperty(nodeId);
      }

      return _objectSpread(_objectSpread({}, items), {}, {
        id: nodeId,
        name: name,
        isSelected: isSelected,
        onClick: function onClick() {
          return console.log('open side nav');
        }
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "renderNodeData", function (node, expandedRowMap) {
      var items = [];
      var columns = [];
      var records = [];
      var data = node.data;

      if (Array.isArray(data)) {
        items = data;
        columns = (0, _typeof2.default)(items[0]) === "object" ? Object.keys(items[0]) : [];
      } else if ((0, _typeof2.default)(data) === "object") {
        records.push(data);
        items = records;
        columns = _this.addExpandingIconColumn(Object.keys(data));
      }

      return /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement(_eui.EuiTable, {
        className: "sideNav-table"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiTableHeader, {
        className: "table-header"
      }, _this.renderHeaderCellsWithNoSorting(columns)), /*#__PURE__*/_react.default.createElement(_eui.EuiTableBody, null, _this.renderRow(items, columns, node.nodeId.toString(), expandedRowMap))));
    });
    _this.state = {
      itemIdToSelectedMap: {},
      itemIdToOpenActionsPopoverMap: {},
      incremental: true,
      filters: false,
      itemIdToExpandedRowMap: _this.props.itemIdToExpandedRowMap,
      searchQuery: _this.props.searchQuery,
      selectedItemMap: {},
      selectedItemName: "",
      selectedItemData: {},
      navView: false,
      isPopoverOpen: false,
      isDownloadPopoverOpen: false
    };
    _this.expandedRowColSpan = 0;
    _this.items = [];
    _this.columns = [];
    _this.panels = []; // Downloads Action button

    _this.panels = [{
      id: 0,
      title: "Download",
      items: [{
        name: "Download JSON",
        onClick: function onClick() {
          _this.onDownloadJSON();
        }
      }, {
        name: "Download JDBC",
        onClick: function onClick() {
          _this.onDownloadJDBC();
        }
      }, {
        name: "Download CSV",
        onClick: function onClick() {
          _this.onDownloadCSV();
        }
      }, {
        name: "Download Text",
        onClick: function onClick() {
          _this.onDownloadText();
        }
      }]
    }];
    return _this;
  } // Actions for Download files


  (0, _createClass2.default)(QueryResultsBody, [{
    key: "getItems",
    // It sorts and filters table values
    value: function getItems(records) {
      var matchingItems = this.props.searchQuery ? _eui.EuiSearchBar.Query.execute(this.props.searchQuery, records) : records;
      return this.props.sortableProperties.sortItems(matchingItems);
    } // It processes field values and determines whether it should link to an expanded row or an expanded array

  }, {
    key: "getFieldValue",
    value: function getFieldValue(fieldValue, field) {
      var hasExpandingRow = false;
      var hasExpandingArray = false;
      var value = "";
      var link = "";

      if (fieldValue === null) {
        return {
          hasExpandingRow: hasExpandingRow,
          value: "",
          hasExpandingArray: hasExpandingArray,
          link: link
        };
      } // Not an object or array


      if ((0, _typeof2.default)(fieldValue) !== "object") {
        return {
          hasExpandingRow: hasExpandingRow,
          value: fieldValue,
          hasExpandingArray: hasExpandingArray,
          link: link
        };
      } // Array of strings or objects


      if (Array.isArray(fieldValue)) {
        if ((0, _typeof2.default)(fieldValue[0]) !== "object") {
          hasExpandingArray = true;
          link = field.concat(": [", fieldValue.length.toString(), "]");
        } else {
          hasExpandingRow = true;
          link = field.concat(": {", fieldValue.length.toString(), "}");
        }
      } // Single object
      else {
          hasExpandingRow = true;
          link = field.concat(": {1}");
        }

      return {
        hasExpandingRow: hasExpandingRow,
        hasExpandingArray: hasExpandingArray,
        value: value,
        link: link
      };
    }
  }, {
    key: "addExpandingNodeIcon",
    value: function addExpandingNodeIcon(node, expandedRowMap) {
      var _this2 = this;

      return /*#__PURE__*/_react.default.createElement(_eui.EuiButtonIcon, {
        onClick: function onClick() {
          return _this2.toggleNodeData(node, expandedRowMap);
        },
        "aria-label": expandedRowMap[node.nodeId] && expandedRowMap[node.nodeId].expandedRow ? "Collapse" : "Expand",
        iconType: expandedRowMap[node.nodeId] && expandedRowMap[node.nodeId].expandedRow ? "minusInCircle" : "plusInCircle"
      });
    }
  }, {
    key: "addExpandingSideNavIcon",
    value: function addExpandingSideNavIcon(node, expandedRowMap) {
      var _this3 = this;

      if (!node.parent) {
        return;
      }

      return /*#__PURE__*/_react.default.createElement(_eui.EuiButtonIcon, {
        onClick: function onClick() {
          return _this3.updateExpandedRowMap(node, expandedRowMap);
        },
        "aria-label": expandedRowMap[node.parent.nodeId] && expandedRowMap[node.parent.nodeId].selectedNodes && expandedRowMap[node.parent.nodeId].selectedNodes.hasOwnProperty(node.nodeId) ? "Collapse" : "Expand",
        iconType: expandedRowMap[node.parent.nodeId] && expandedRowMap[node.parent.nodeId].selectedNodes && expandedRowMap[node.parent.nodeId].selectedNodes.hasOwnProperty(node.nodeId) ? "minusInCircle" : "plusInCircle"
      });
    }
  }, {
    key: "addExpandingIconColumn",
    value: function addExpandingIconColumn(columns) {
      var expandIconColumn = [{
        id: "expandIcon",
        label: "",
        isSortable: false,
        width: "30px"
      }];
      columns = expandIconColumn.concat(columns);
      return columns;
    }
  }, {
    key: "updateSelectedNodes",
    value: function updateSelectedNodes(parentNode, selectedNode, expandedRowMap) {
      var keepOpen = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

      if (!parentNode) {
        return expandedRowMap;
      }

      var parentNodeId = parentNode.nodeId;

      if (expandedRowMap[parentNodeId] && expandedRowMap[parentNodeId].selectedNodes && expandedRowMap[parentNodeId].selectedNodes.hasOwnProperty(selectedNode.nodeId) && !keepOpen) {
        delete expandedRowMap[parentNodeId].selectedNodes[selectedNode.nodeId];
      } else {
        if (!expandedRowMap[parentNodeId].selectedNodes) {
          expandedRowMap[parentNodeId].selectedNodes = {};
        }

        expandedRowMap[parentNodeId].selectedNodes[selectedNode.nodeId] = selectedNode.data;
      }

      return expandedRowMap;
    }
  }, {
    key: "updateExpandedRow",
    value: function updateExpandedRow(node, expandedRowMap) {
      var newItemIdToExpandedRowMap = expandedRowMap;

      if (expandedRowMap[node.nodeId]) {
        newItemIdToExpandedRowMap[node.nodeId].expandedRow = /*#__PURE__*/_react.default.createElement("div", {
          id: node.nodeId,
          style: {
            padding: "0 0 20px 19px"
          }
        }, this.renderNav(node, node.name, expandedRowMap));
      }

      return newItemIdToExpandedRowMap;
    }
  }, {
    key: "updateExpandedRowMap",
    value: function updateExpandedRowMap(node, expandedRowMap) {
      var keepOpen = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

      if (!node) {
        return expandedRowMap;
      }

      var newItemIdToExpandedRowMap = this.updateSelectedNodes(node.parent, node, expandedRowMap, keepOpen);
      var rootNode = (0, _utils.findRootNode)(node, expandedRowMap);

      if (expandedRowMap[rootNode.nodeId]) {
        newItemIdToExpandedRowMap = this.updateExpandedRow(node.parent, newItemIdToExpandedRowMap);
        newItemIdToExpandedRowMap = this.updateExpandedRow(rootNode, newItemIdToExpandedRowMap);
      }

      this.props.updateExpandedMap(newItemIdToExpandedRowMap);
    }
  }, {
    key: "getChildrenItems",
    value: function getChildrenItems(nodes, parentNode, expandedRowMap) {
      var itemList = [];

      if (nodes.length === 0 && parentNode.data) {
        var renderedData = this.renderNodeData(parentNode, expandedRowMap);
        itemList.push(this.createItem(expandedRowMap, parentNode, renderedData, {
          items: []
        }));
      }

      for (var i = 0; i < nodes.length; i++) {
        itemList.push(this.createItem(expandedRowMap, nodes[i], nodes[i].name, {
          icon: this.addExpandingSideNavIcon(nodes[i], expandedRowMap),
          items: this.getChildrenItems(nodes[i].children, nodes[i], expandedRowMap)
        }));
      }

      return itemList;
    }
  }, {
    key: "renderMessagesTab",

    /************* Render Functions *************/
    value: function renderMessagesTab() {
      return /*#__PURE__*/_react.default.createElement(_eui.EuiCodeEditor, {
        className: this.props.messages && this.props.messages.length > 0 ? this.props.messages[0].className : "successful-message",
        mode: "text",
        theme: "sql_console",
        width: "100%",
        value: (0, _utils.getMessageString)(this.props.messages, this.props.tabNames),
        showPrintMargin: false,
        readOnly: true,
        setOptions: {
          fontSize: "14px",
          readOnly: true,
          highlightActiveLine: false,
          highlightGutterLine: false
        },
        "aria-label": "Code Editor"
      });
    }
  }, {
    key: "renderHeaderCells",
    value: function renderHeaderCells(columns) {
      var _this4 = this;

      return columns.map(function (field) {
        var label = field.id === "expandIcon" ? field.label : field;
        var colwidth = field.id === "expandIcon" || field === "id" ? _constants.SMALL_COLUMN_WIDTH : _constants.COLUMN_WIDTH;
        return /*#__PURE__*/_react.default.createElement(_eui.EuiTableHeaderCell, {
          key: label,
          width: colwidth,
          onSort: _this4.props.onSort.bind(_this4, field),
          isSorted: _this4.props.sortedColumn === field,
          isSortAscending: _this4.props.sortableProperties.isAscendingByName(field)
        }, label);
      });
    } // Inner tables sorting is not enabled

  }, {
    key: "renderHeaderCellsWithNoSorting",
    value: function renderHeaderCellsWithNoSorting(columns) {
      return columns.map(function (field) {
        var label = field.id === "expandIcon" ? field.label : field;
        var colwidth = field.id === "expandIcon" ? field.width : _constants.COLUMN_WIDTH;
        return /*#__PURE__*/_react.default.createElement(_eui.EuiTableHeaderCell, {
          key: label,
          width: colwidth
        }, label);
      });
    }
  }, {
    key: "renderRow",
    value: function renderRow(item, columns, rowId, expandedRowMap) {
      var _this5 = this;

      var rows = []; // If the item is an array or an object we add it to the expandedRowMap

      if (item && ((0, _typeof2.default)(item) === "object" && !(0, _utils.isEmpty)(item) || Array.isArray(item) && item.length > 0)) {
        var rowItems = [];

        if (Array.isArray(item)) {
          rowItems = item;
        } else {
          rowItems.push(item);
        }

        var _loop = function _loop(i) {
          var rowItem = rowItems[i];
          var tableCells = [];
          var tree = (0, _utils.getRowTree)(rowId, rowItem, expandedRowMap); // Add nodes to expandedRowMap

          if (!expandedRowMap[rowId] || !expandedRowMap[rowId].nodes) {
            expandedRowMap[rowId] = {
              nodes: tree
            };
          }

          var expandingNode = tree && tree._root.children.length > 0 ? _this5.addExpandingNodeIcon(tree._root, expandedRowMap) : "";

          if (columns.length > 0) {
            columns.map(function (field) {
              // Table cell
              if (field.id !== "expandIcon") {
                var fieldObj = _this5.getFieldValue(rowItem[field], field);

                var fieldValue; // If field is expandable

                if (fieldObj.hasExpandingRow || fieldObj.hasExpandingArray) {
                  var fieldNode = expandedRowMap[tree._root.nodeId].nodes._root.children.find(function (node) {
                    return node.name === field;
                  });

                  fieldValue = /*#__PURE__*/_react.default.createElement("span", null, " ", fieldObj.value, /*#__PURE__*/_react.default.createElement(_eui.EuiLink, {
                    color: "primary",
                    onClick: function onClick() {
                      _this5.updateExpandedRowMap(fieldNode, expandedRowMap, true);

                      (0, _utils.scrollToNode)(tree._root.nodeId);
                    }
                  }, fieldObj.link));
                } else {
                  fieldValue = fieldObj.value;
                }

                tableCells.push( /*#__PURE__*/_react.default.createElement(_eui.EuiTableRowCell, {
                  key: field,
                  truncateText: false,
                  textOnly: true
                }, fieldValue));
              } // Expanding icon cell
              else {
                  tableCells.push( /*#__PURE__*/_react.default.createElement(_eui.EuiTableRowCell, {
                    id: tree._root.nodeId
                  }, expandingNode));
                }
            });
          } else {
            var fieldObj = _this5.getFieldValue(rowItem, "");

            tableCells.push( /*#__PURE__*/_react.default.createElement(_eui.EuiTableRowCell, {
              truncateText: false,
              textOnly: true
            }, fieldObj.value));
          }

          var tableRow = /*#__PURE__*/_react.default.createElement(_eui.EuiTableRow, {
            key: rowId,
            "data-test-subj": 'tableRow'
          }, tableCells, " ");

          var row = /*#__PURE__*/_react.default.createElement(_react.Fragment, null, tableRow);

          if (expandedRowMap[rowId] && expandedRowMap[rowId].expandedRow) {
            var _tableRow = /*#__PURE__*/_react.default.createElement(_eui.EuiTableRow, {
              className: "expanded-row",
              key: rowId
            }, tableCells, " ");

            var expandedRow = /*#__PURE__*/_react.default.createElement(_eui.EuiTableRow, null, expandedRowMap[rowId].expandedRow);

            row = /*#__PURE__*/_react.default.createElement(_react.Fragment, null, _tableRow, expandedRow);
          }

          rows.push(row);
        };

        for (var i = 0; i < rowItems.length; i++) {
          _loop(i);
        }
      }

      return rows;
    }
  }, {
    key: "renderRows",
    value: function renderRows(items, columns, expandedRowMap) {
      var rows = [];

      if (items) {
        for (var itemIndex = this.props.firstItemIndex; itemIndex <= this.props.lastItemIndex; itemIndex++) {
          var item = items[itemIndex];

          if (item) {
            var rowId = item["id"].toString();
            var rowsForItem = this.renderRow(item, columns, rowId, expandedRowMap);
            rows.push(rowsForItem);
          }
        }
      }

      return rows;
    }
  }, {
    key: "renderSearchBar",
    value: function renderSearchBar() {
      var search = {
        box: {
          incremental: this.state.incremental,
          placeholder: "Search",
          schema: true
        }
      };
      return /*#__PURE__*/_react.default.createElement("div", {
        className: "search-bar"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiSearchBar, (0, _extends2.default)({
        onChange: this.props.onQueryChange,
        query: this.props.searchQuery
      }, search)));
    }
  }, {
    key: "renderNav",
    value: function renderNav(node, table_name, expandedRowMap) {
      var sideNav = [{
        items: this.getChildrenItems(node.children, node, expandedRowMap),
        id: node.nodeId,
        name: node.name,
        isSelected: false,
        onClick: function onClick() {
          return console.log('open side nav');
        }
      }];
      return /*#__PURE__*/_react.default.createElement(_eui.EuiSideNav, {
        mobileTitle: "Navigate within $APP_NAME",
        items: sideNav,
        className: "sideNavItem__items",
        style: {
          width: "300px",
          padding: "0 0 20px 9px"
        }
      });
    }
  }, {
    key: "render",
    value: function render() {
      // Action button with list of downloads
      var downloadsButton = /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        iconType: "arrowDown",
        iconSide: "right",
        onClick: this.onDownloadButtonClick
      }, "Download");

      if ( // this.props.selectedTabId === MESSAGE_TAB_LABEL ||
      this.props.queryResultSelected == undefined) {
        return this.renderMessagesTab();
      } else {
        if (this.props.queryResultSelected) {
          this.items = this.getItems(this.props.queryResultSelected.records); //Adding an extra empty column for the expanding icon

          this.columns = this.addExpandingIconColumn(this.props.queryResultSelected.fields);
          this.expandedRowColSpan = this.columns.length;
        }

        return /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
          size: "m"
        }), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
          justifyContent: "spaceBetween"
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
          grow: 7
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
          className: "table-name"
        }, (0, _utils.capitalizeFirstLetter)(this.props.selectedTabName))), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
          grow: 1
        }, /*#__PURE__*/_react.default.createElement("div", {
          className: "download-container"
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiPopover, {
          className: "download-button-container",
          id: "singlePanel",
          button: downloadsButton,
          isOpen: this.state.isDownloadPopoverOpen,
          closePopover: this.closeDownloadPopover,
          panelPaddingSize: "none",
          anchorPosition: "downLeft"
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiContextMenu, {
          initialPanelId: 0,
          panels: this.panels
        }))))), /*#__PURE__*/_react.default.createElement(_eui.EuiHorizontalRule, {
          margin: "none"
        }), /*#__PURE__*/_react.default.createElement("div", {
          className: "search-panel"
        }, this.renderSearchBar(), /*#__PURE__*/_react.default.createElement(_eui.EuiTablePagination, {
          activePage: this.props.pager.getCurrentPageIndex(),
          itemsPerPage: this.props.itemsPerPage,
          itemsPerPageOptions: _constants.PAGE_OPTIONS,
          pageCount: this.props.pager.getTotalPages(),
          onChangeItemsPerPage: this.props.onChangeItemsPerPage,
          onChangePage: this.props.onChangePage,
          "data-test-subj": "Pagination-button"
        })), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
          size: "m"
        }), /*#__PURE__*/_react.default.createElement("div", {
          className: "sql-console-results-container"
        }, /*#__PURE__*/_react.default.createElement(DoubleScrollbar, null, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
          gutterSize: "none"
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, null, /*#__PURE__*/_react.default.createElement(_eui.EuiTable, null, /*#__PURE__*/_react.default.createElement(_eui.EuiTableHeader, {
          className: "table-header"
        }, this.renderHeaderCells(this.columns)), /*#__PURE__*/_react.default.createElement(_eui.EuiTableBody, null, this.renderRows(this.items, this.columns, this.props.itemIdToExpandedRowMap))))))), /*#__PURE__*/_react.default.createElement("div", {
          className: "pagination-container"
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiTablePagination, {
          activePage: this.props.pager.getCurrentPageIndex(),
          itemsPerPage: this.props.itemsPerPage,
          itemsPerPageOptions: _constants.PAGE_OPTIONS,
          pageCount: this.props.pager.getTotalPages(),
          onChangeItemsPerPage: this.props.onChangeItemsPerPage,
          onChangePage: this.props.onChangePage
        })));
      }
    }
  }]);
  return QueryResultsBody;
}(_react.default.Component);

var _default = QueryResultsBody;
exports.default = _default;
module.exports = exports.default;
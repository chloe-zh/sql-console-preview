"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Main", {
  enumerable: true,
  get: function get() {
    return _main.Main;
  }
});

var _main = require("./main");
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getQueryResultsForTable = getQueryResultsForTable;
exports.default = exports.Main = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

var _lodash = _interopRequireDefault(require("lodash"));

var _Header = _interopRequireDefault(require("../Header/Header"));

var _QueryEditor = _interopRequireDefault(require("../QueryEditor/QueryEditor"));

var _QueryResults = _interopRequireDefault(require("../QueryResults/QueryResults"));

var _Switch = _interopRequireDefault(require("../QueryLanguageSwitch/Switch"));

var _utils = require("../../utils/utils");

var _constants = require("../../utils/constants");

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

var SUCCESS_MESSAGE = "Success"; // It gets column names and row values to display in a Table from the json API response

function getQueryResultsForTable(queryResults) {
  return queryResults.map(function (queryResultResponseDetail) {
    if (!queryResultResponseDetail.fulfilled) {
      return {
        fulfilled: queryResultResponseDetail.fulfilled,
        errorMessage: queryResultResponseDetail.errorMessage
      };
    } else {
      var databaseRecords = [];
      var responseObj = queryResultResponseDetail.data ? JSON.parse(queryResultResponseDetail.data) : '';
      var databaseFields = [];
      var fields = [];

      var schema = _lodash.default.get(responseObj, 'schema');

      var datarows = _lodash.default.get(responseObj, 'datarows');

      var queryType = 'default';

      var _iterator = _createForOfIteratorHelper(schema.values()),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var column = _step.value;

          if (_lodash.default.isEqual(_lodash.default.get(column, 'name'), 'TABLE_NAME')) {
            queryType = 'show';

            var _iterator7 = _createForOfIteratorHelper(schema.values()),
                _step7;

            try {
              for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
                var col = _step7.value;
                if (_lodash.default.isEqual(_lodash.default.get(col, 'name'), 'DATA_TYPE')) queryType = 'describe';
              }
            } catch (err) {
              _iterator7.e(err);
            } finally {
              _iterator7.f();
            }
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      switch (queryType) {
        case 'show':
          databaseFields[0] = 'TABLE_NAME';
          databaseFields.unshift('id');
          var index = -1;

          var _iterator2 = _createForOfIteratorHelper(schema.entries()),
              _step2;

          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var _step2$value = (0, _slicedToArray2.default)(_step2.value, 2),
                  _id = _step2$value[0],
                  field = _step2$value[1];

              if (_lodash.default.eq(_lodash.default.get(field, 'name'), 'TABLE_NAME')) {
                index = _id;
                break;
              }
            }
          } catch (err) {
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }

          var _iterator3 = _createForOfIteratorHelper(datarows.entries()),
              _step3;

          try {
            for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
              var _step3$value = (0, _slicedToArray2.default)(_step3.value, 2),
                  _id2 = _step3$value[0],
                  datarow = _step3$value[1];

              var _databaseRecord = {};
              _databaseRecord['id'] = _id2;
              _databaseRecord['TABLE_NAME'] = datarow[index];
              databaseRecords.push(_databaseRecord);
            }
          } catch (err) {
            _iterator3.e(err);
          } finally {
            _iterator3.f();
          }

          break;

        case 'describe':
        case 'default':
          var _iterator4 = _createForOfIteratorHelper(schema.entries()),
              _step4;

          try {
            for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
              var _step4$value = (0, _slicedToArray2.default)(_step4.value, 2),
                  _id3 = _step4$value[0],
                  _field = _step4$value[1];

              var alias = null;

              try {
                alias = _lodash.default.get(_field, 'alias');
              } catch (e) {
                console.log('No alias for field ' + _field);
              } finally {
                fields[_id3] = !alias ? _lodash.default.get(_field, 'name') : alias;
              }
            }
          } catch (err) {
            _iterator4.e(err);
          } finally {
            _iterator4.f();
          }

          databaseFields = fields;
          databaseFields.unshift("id");

          var _iterator5 = _createForOfIteratorHelper(datarows.entries()),
              _step5;

          try {
            for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
              var _step5$value = (0, _slicedToArray2.default)(_step5.value, 2),
                  _id4 = _step5$value[0],
                  _datarow = _step5$value[1];

              var _databaseRecord2 = {};
              _databaseRecord2['id'] = _id4;

              var _iterator6 = _createForOfIteratorHelper(schema.keys()),
                  _step6;

              try {
                for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                  var _index = _step6.value;
                  var fieldname = databaseFields[_index + 1];
                  _databaseRecord2[fieldname] = _datarow[_index];
                }
              } catch (err) {
                _iterator6.e(err);
              } finally {
                _iterator6.f();
              }

              databaseRecords.push(_databaseRecord2);
            }
          } catch (err) {
            _iterator5.e(err);
          } finally {
            _iterator5.f();
          }

          break;

        default:
          var databaseRecord = {};
          databaseRecords.push(databaseRecord);
      }

      return {
        fulfilled: queryResultResponseDetail.fulfilled,
        data: {
          fields: databaseFields,
          records: databaseRecords,
          message: SUCCESS_MESSAGE
        }
      };
    }
  });
}

var Main = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(Main, _React$Component);

  var _super = _createSuper(Main);

  // httpClient: any;
  function Main(props) {
    var _this;

    (0, _classCallCheck2.default)(this, Main);
    _this = _super.call(this, props);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "httpClient", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSelectedTabIdChange", function (tab) {
      _this.setState({
        selectedTabId: tab.id,
        selectedTabName: tab.name,
        searchQuery: " ",
        itemIdToExpandedRowMap: {}
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onQueryChange", function (_ref) {
      var query = _ref.query;

      // Reset pagination state.
      _this.setState({
        searchQuery: query,
        itemIdToExpandedRowMap: {}
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "updateExpandedMap", function (map) {
      _this.setState({
        itemIdToExpandedRowMap: map
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onRun", function (queriesString) {
      var queries = (0, _utils.getQueries)(queriesString);
      var language = _this.state.language;

      if (queries.length > 0) {
        console.log("main: " + language);
        var endpoint = "../api/sql_console/" + (_lodash.default.isEqual(language, 'SQL') ? "sqlquery" : "pplquery");
        var responsePromise = Promise.all(queries.map(function (query) {
          return _this.httpClient.post(endpoint, {
            query: query
          }).catch(function (error) {
            _this.setState({
              messages: [{
                text: error.message,
                className: "error-message"
              }]
            });
          });
        }));
        Promise.all([responsePromise]).then(function (_ref2) {
          var _ref3 = (0, _slicedToArray2.default)(_ref2, 1),
              response = _ref3[0];

          var results = response.map(function (response) {
            return _this.processQueryResponse(response);
          });
          var resultTable = getQueryResultsForTable(results);

          _this.setState({
            queries: queries,
            queryResults: results,
            queryResultsTable: resultTable,
            selectedTabId: (0, _utils.getDefaultTabId)(results),
            selectedTabName: (0, _utils.getDefaultTabLabel)(results, queries[0]),
            messages: _this.getMessage(resultTable),
            itemIdToExpandedRowMap: {},
            queryResultsJSON: [],
            queryResultsCSV: [],
            queryResultsTEXT: [],
            searchQuery: ""
          }, function () {
            return console.log("Successfully updated the states");
          }); // added callback function to handle async issues

        });
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onTranslate", function (queriesString) {
      var queries = (0, _utils.getQueries)(queriesString);

      if (queries.length > 0) {
        var translationPromise = Promise.all(queries.map(function (query) {
          return _this.httpClient.post("../api/sql_console/translate", {
            query: query
          }).catch(function (error) {
            _this.setState({
              messages: [{
                text: error.message,
                className: "error-message"
              }]
            });
          });
        }));
        Promise.all([translationPromise]).then(function (_ref4) {
          var _ref5 = (0, _slicedToArray2.default)(_ref4, 1),
              translationResponse = _ref5[0];

          var translationResult = translationResponse.map(function (translationResponse) {
            return _this.processTranslateResponse(translationResponse);
          });
          var shouldCleanResults = queries == _this.state.queries;

          if (shouldCleanResults) {
            _this.setState({
              queries: queries,
              queryTranslations: translationResult,
              messages: _this.getTranslateMessage(translationResult)
            });
          } else {
            _this.setState({
              queries: queries,
              queryTranslations: translationResult,
              messages: _this.getTranslateMessage(translationResult)
            }, function () {
              return console.log("Successfully updated the states");
            });
          }
        });
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getJson", function (queries) {
      if (queries.length > 0) {
        Promise.all(queries.map(function (query) {
          return _this.httpClient.post("../api/sql_console/queryjson", {
            query: query
          }).catch(function (error) {
            _this.setState({
              messages: [{
                text: error.message,
                className: "error-message"
              }]
            });
          });
        })).then(function (response) {
          var results = response.map(function (response) {
            return _this.processQueryResponse(response);
          });

          _this.setState({
            queries: queries,
            queryResultsJSON: results
          }, function () {
            return console.log("Successfully updated the states");
          });
        });
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getJdbc", function (queries) {
      if (queries.length > 0) {
        Promise.all(queries.map(function (query) {
          return _this.httpClient.post("../api/sql_console/query", {
            query: query
          }).catch(function (error) {
            _this.setState({
              messages: [{
                text: error.message,
                className: "error-message"
              }]
            });
          });
        })).then(function (jdbcResponse) {
          var jdbcResult = jdbcResponse.map(function (jdbcResponse) {
            return _this.processQueryResponse(jdbcResponse);
          });

          _this.setState({
            queries: queries,
            queryResults: jdbcResult
          }, function () {
            return console.log("Successfully updated the states");
          });
        });
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getCsv", function (queries) {
      if (queries.length > 0) {
        Promise.all(queries.map(function (query) {
          return _this.httpClient.post("../api/sql_console/querycsv", {
            query: query
          }).catch(function (error) {
            _this.setState({
              messages: [{
                text: error.message,
                className: "error-message"
              }]
            });
          });
        })).then(function (csvResponse) {
          var csvResult = csvResponse.map(function (csvResponse) {
            return _this.processQueryResponse(csvResponse);
          });

          _this.setState({
            queries: queries,
            queryResultsCSV: csvResult
          }, function () {
            return console.log("Successfully updated the states");
          });
        });
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "getText", function (queries) {
      if (queries.length > 0) {
        Promise.all(queries.map(function (query) {
          return _this.httpClient.post("../api/sql_console/querytext", {
            query: query
          }).catch(function (error) {
            _this.setState({
              messages: [{
                text: error.message,
                className: "error-message"
              }]
            });
          });
        })).then(function (textResponse) {
          var textResult = textResponse.map(function (textResponse) {
            return _this.processQueryResponse(textResponse);
          });

          _this.setState({
            queries: queries,
            queryResultsTEXT: textResult
          }, function () {
            return console.log("Successfully updated the states");
          });
        });
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onClear", function () {
      _this.setState({
        queries: [],
        queryTranslations: [],
        queryResultsTable: [],
        queryResults: [],
        queryResultsCSV: [],
        queryResultsJSON: [],
        queryResultsTEXT: [],
        messages: [],
        selectedTabId: _constants.MESSAGE_TAB_LABEL,
        selectedTabName: _constants.MESSAGE_TAB_LABEL,
        itemIdToExpandedRowMap: {}
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChange", function (id) {
      _this.setState({
        language: id
      }, function () {
        return console.log("Successfully updated language to ", _this.state.language);
      }); // added callback function to handle async issues

    });
    _this.onChange = _this.onChange.bind((0, _assertThisInitialized2.default)(_this));
    _this.state = {
      language: 'SQL',
      queries: [],
      queryTranslations: [],
      queryResultsTable: [],
      queryResults: [],
      queryResultsJSON: [],
      queryResultsCSV: [],
      queryResultsTEXT: [],
      selectedTabName: _constants.MESSAGE_TAB_LABEL,
      selectedTabId: _constants.MESSAGE_TAB_LABEL,
      searchQuery: "",
      itemIdToExpandedRowMap: {},
      messages: []
    };
    _this.httpClient = _this.props.httpClient;
    return _this;
  }

  (0, _createClass2.default)(Main, [{
    key: "processTranslateResponse",
    value: function processTranslateResponse(response) {
      if (!response) {
        return {
          fulfilled: false,
          errorMessage: "no response",
          data: undefined
        };
      }

      if (!response.data.ok) {
        return {
          fulfilled: false,
          errorMessage: response.data.resp,
          data: undefined
        };
      }

      return {
        fulfilled: true,
        data: response.data.resp
      };
    }
  }, {
    key: "processQueryResponse",
    value: function processQueryResponse(response) {
      if (!response) {
        return {
          fulfilled: false,
          errorMessage: "no response",
          data: ''
        };
      }

      if (!response.data.ok) {
        return {
          fulfilled: false,
          errorMessage: response.data.resp,
          data: ''
        };
      }

      return {
        fulfilled: true,
        data: response.data.resp
      };
    }
  }, {
    key: "getMessage",
    // It returns the error or successful message to display in the Message Tab
    value: function getMessage(queryResultsForTable) {
      return queryResultsForTable.map(function (queryResult) {
        return {
          text: queryResult.fulfilled && queryResult.data ? queryResult.data.message : queryResult.errorMessage,
          className: queryResult.fulfilled ? "successful-message" : "error-message"
        };
      });
    }
  }, {
    key: "getTranslateMessage",
    value: function getTranslateMessage(translationResult) {
      return translationResult.map(function (translation) {
        return {
          text: translation.data ? SUCCESS_MESSAGE : translation.errorMessage,
          className: translation.fulfilled ? "successful-message" : "error-message"
        };
      });
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement(_Header.default, null), /*#__PURE__*/_react.default.createElement("div", {
        className: "sql-console-query-container"
      }, /*#__PURE__*/_react.default.createElement("div", {
        className: "query-language-switch"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, null, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, null, /*#__PURE__*/_react.default.createElement(_Switch.default, {
        onChange: this.onChange,
        language: this.state.language
      })), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        href: "https://opendistro.github.io/for-elasticsearch-docs/docs/sql/",
        iconType: "popout",
        iconSide: "right"
      }, "SQL Documentation")))), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "l"
      }), /*#__PURE__*/_react.default.createElement("div", {
        className: "sql-console-query-editor"
      }, /*#__PURE__*/_react.default.createElement(_QueryEditor.default, {
        onRun: this.onRun,
        onTranslate: this.onTranslate,
        onClear: this.onClear,
        sqlQueriesString: this.props.sqlQueriesString ? this.props.sqlQueriesString : '',
        queryTranslations: this.state.queryTranslations
      })), /*#__PURE__*/_react.default.createElement(_eui.EuiSpacer, {
        size: "l"
      }), /*#__PURE__*/_react.default.createElement("div", {
        className: "sql-console-query-result"
      }, /*#__PURE__*/_react.default.createElement(_QueryResults.default, {
        queries: this.state.queries,
        queryResults: this.state.queryResultsTable,
        queryResultsJDBC: (0, _utils.getSelectedResults)(this.state.queryResults, this.state.selectedTabId),
        queryResultsJSON: (0, _utils.getSelectedResults)(this.state.queryResultsJSON, this.state.selectedTabId),
        queryResultsCSV: (0, _utils.getSelectedResults)(this.state.queryResultsCSV, this.state.selectedTabId),
        queryResultsTEXT: (0, _utils.getSelectedResults)(this.state.queryResultsTEXT, this.state.selectedTabId),
        messages: this.state.messages,
        selectedTabId: this.state.selectedTabId,
        selectedTabName: this.state.selectedTabName,
        onSelectedTabIdChange: this.onSelectedTabIdChange,
        itemIdToExpandedRowMap: this.state.itemIdToExpandedRowMap,
        onQueryChange: this.onQueryChange,
        updateExpandedMap: this.updateExpandedMap,
        searchQuery: this.state.searchQuery,
        tabsOverflow: false,
        getJson: this.getJson,
        getJdbc: this.getJdbc,
        getCsv: this.getCsv,
        getText: this.getText
      }))));
    }
  }]);
  return Main;
}(_react.default.Component);

exports.Main = Main;
var _default = Main;
exports.default = _default;
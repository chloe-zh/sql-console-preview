"use strict";

require("@testing-library/react/cleanup-after-each");

require("@testing-library/jest-dom/extend-expect");

require("mutationobserver-shim");

var _react = require("@testing-library/react");

/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
(0, _react.configure)({
  testIdAttribute: "data-test-subj"
});
jest.mock("@elastic/eui/lib/components/form/form_row/make_id", function () {
  return function () {
    return "some_make_id";
  };
});
jest.mock("@elastic/eui/lib/services/accessibility/html_id_generator", function () {
  return {
    htmlIdGenerator: function htmlIdGenerator() {
      return function () {
        return "some_html_id";
      };
    }
  };
}); // @ts-ignore

window.Worker = function () {
  this.postMessage = function () {}; // @ts-ignore


  this.terminate = function () {};
}; // @ts-ignore


window.URL = {
  createObjectURL: function createObjectURL() {
    return "";
  }
};
jest.mock("@elastic/eui/lib/components/icon", function () {
  return {
    EuiIcon: function EuiIcon() {
      return "EuiIconMock";
    },
    __esModule: true,
    IconPropType: require("@elastic/eui/lib/components/icon/icon").IconPropType,
    ICON_TYPES: require("@elastic/eui/lib/components/icon/icon").TYPES,
    ICON_SIZES: require("@elastic/eui/lib/components/icon/icon").SIZES,
    ICON_COLORS: require("@elastic/eui/lib/components/icon/icon").COLORS
  };
});
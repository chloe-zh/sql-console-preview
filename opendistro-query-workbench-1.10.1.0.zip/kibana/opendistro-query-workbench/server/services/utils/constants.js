"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CLUSTER = exports.DEFAULT_HEADERS = exports.FORMAT_TEXT = exports.FORMAT_JSON = exports.FORMAT_CSV = exports.PPL_QUERY_ROUTE = exports.SQL_QUERY_ROUTE = exports.PPL_TRANSLATE_ROUTE = exports.SQL_TRANSLATE_ROUTE = void 0;

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
var SQL_TRANSLATE_ROUTE = "_opendistro/_sql/_explain";
exports.SQL_TRANSLATE_ROUTE = SQL_TRANSLATE_ROUTE;
var PPL_TRANSLATE_ROUTE = "_opendistro/_ppl/_explain";
exports.PPL_TRANSLATE_ROUTE = PPL_TRANSLATE_ROUTE;
var SQL_QUERY_ROUTE = "_opendistro/_sql";
exports.SQL_QUERY_ROUTE = SQL_QUERY_ROUTE;
var PPL_QUERY_ROUTE = "_opendistro/_ppl";
exports.PPL_QUERY_ROUTE = PPL_QUERY_ROUTE;
var FORMAT_CSV = "format=csv";
exports.FORMAT_CSV = FORMAT_CSV;
var FORMAT_JSON = "format=json";
exports.FORMAT_JSON = FORMAT_JSON;
var FORMAT_TEXT = "format=raw";
exports.FORMAT_TEXT = FORMAT_TEXT;
var DEFAULT_HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'User-Agent': 'Kibana'
};
exports.DEFAULT_HEADERS = DEFAULT_HEADERS;
var CLUSTER = {
  ADMIN: 'admin',
  SQL: 'opendistro_sql',
  DATA: 'data'
};
exports.CLUSTER = CLUSTER;
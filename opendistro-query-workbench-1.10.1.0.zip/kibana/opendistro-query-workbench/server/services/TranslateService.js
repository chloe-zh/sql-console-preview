"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));

var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _constants = require("./utils/constants");

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
var TranslateService = function TranslateService(client) {
  var _this = this;

  (0, _classCallCheck2.default)(this, TranslateService);
  (0, _defineProperty2.default)(this, "client", void 0);
  (0, _defineProperty2.default)(this, "translateQuery", /*#__PURE__*/function () {
    var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(request, h, err) {
      var params, _yield$_this$client$g, callWithRequest, createResponse;

      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              params = {
                body: JSON.stringify(request.payload)
              };
              _context.next = 4;
              return _this.client.getCluster(_constants.CLUSTER.SQL);

            case 4:
              _yield$_this$client$g = _context.sent;
              callWithRequest = _yield$_this$client$g.callWithRequest;
              _context.next = 8;
              return callWithRequest(request, 'sql.getTranslation', params);

            case 8:
              createResponse = _context.sent;
              return _context.abrupt("return", h.response({
                ok: true,
                resp: createResponse
              }));

            case 12:
              _context.prev = 12;
              _context.t0 = _context["catch"](0);
              return _context.abrupt("return", h.response({
                ok: false,
                resp: _context.t0.message
              }));

            case 15:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[0, 12]]);
    }));

    return function (_x, _x2, _x3) {
      return _ref.apply(this, arguments);
    };
  }());
  this.client = client;
};

exports.default = TranslateService;
module.exports = exports.default;
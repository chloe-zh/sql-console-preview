"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = query;

var _constants = require("../utils/constants");

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
function query(server, service) {
  server.route({
    path: _constants.ROUTE_PATH_SQL_QUERY,
    method: 'POST',
    handler: service.describeSQLQuery
  });
  server.route({
    path: _constants.ROUTE_PATH_PPL_QUERY,
    method: 'POST',
    handler: service.describePPLQuery
  });
  server.route({
    path: _constants.ROUTE_PATH_QUERY_CSV,
    method: 'POST',
    handler: service.describeQueryCsv
  });
  server.route({
    path: _constants.ROUTE_PATH_QUERY_JSON,
    method: 'POST',
    handler: service.describeQueryJson
  });
  server.route({
    path: _constants.ROUTE_PATH_QUERY_JDBC,
    method: 'POST',
    handler: service.describeQueryJdbc
  });
  server.route({
    path: _constants.ROUTE_PATH_QUERY_TEXT,
    method: 'POST',
    handler: service.describeQueryText
  });
}

module.exports = exports.default;
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
import { GanttChart } from './components/gantt_chart';
import { GanttChartEditor } from './components/gantt_chart_editor';
import { AxesEditor } from './components/axes_editor';
import { PanelEditor } from './components/panel_editor';
import { getGanttRequestHandler } from './gantt_request_handler';

var getGanttResponseHandler = function getGanttResponseHandler() {
  return /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(_ref) {
      var total, hits, responseData;
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              total = _ref.total, hits = _ref.hits;
              responseData = {
                total: total,
                source: hits.map(function (hit) {
                  return hit._source;
                })
              };
              return _context.abrupt("return", responseData);

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }();
};

export function getGanttVisDefinition(dependencies) {
  var ganttRequestHandler = getGanttRequestHandler(dependencies);
  var ganttResponseHandler = getGanttResponseHandler();
  var ganttParams = {
    labelField: '',
    startTimeField: '',
    durationField: '',
    size: 10,
    yAxisPosition: 'left',
    yAxisShow: true,
    yAxisShowLabels: true,
    yAxisTitle: '',
    xAxisPosition: 'bottom',
    xAxisType: 'linear',
    xAxisShow: true,
    xAxisShowLabels: true,
    xAxisTitle: '',
    legendOrientation: 'v',
    showLegend: true,
    xAxisShowGrid: true,
    yAxisShowGrid: false,
    useDefaultColors: false,
    colors: '#6092C0'
  };
  return {
    name: 'gantt_vis',
    title: 'Gantt Chart',
    icon: 'visBarHorizontalStacked',
    description: 'This visualization allows you to create a Gantt chart.',
    visConfig: {
      component: GanttChart,
      defaults: ganttParams
    },
    editorConfig: {
      optionTabs: [{
        name: 'gantt_chart_editor',
        title: 'Data',
        editor: GanttChartEditor
      }, {
        name: 'axes_editor',
        title: 'Axes',
        editor: AxesEditor
      }, {
        name: 'panel_editor',
        title: 'Panel Settings',
        editor: PanelEditor
      }]
    },
    requestHandler: ganttRequestHandler,
    responseHandler: ganttResponseHandler
  };
}
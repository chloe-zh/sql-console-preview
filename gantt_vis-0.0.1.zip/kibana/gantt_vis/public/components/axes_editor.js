/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
import { EuiFieldText, EuiFormRow, EuiHorizontalRule, EuiPanel, EuiSelect, EuiSpacer, EuiSwitch, EuiTitle } from '@elastic/eui';
import React from 'react';
export function AxesEditor(_ref) {
  var aggs = _ref.aggs,
      stateParams = _ref.stateParams,
      setValue = _ref.setValue;
  var yAxisPositionOptions = [{
    value: 'left',
    text: 'Left'
  }, {
    value: 'right',
    text: 'Right'
  }];
  var xAxisPositionOptions = [{
    value: 'top',
    text: 'Top'
  }, {
    value: 'bottom',
    text: 'Bottom'
  }];
  var axisTypeOptions = [{
    value: '-',
    text: 'Auto'
  }, {
    value: 'linear',
    text: 'Linear'
  }, {
    value: 'log',
    text: 'Log'
  }, {
    value: 'date',
    text: 'Date'
  }, {
    value: 'category',
    text: 'Category'
  }];

  var renderYAxisOptions = function renderYAxisOptions() {
    return /*#__PURE__*/React.createElement(EuiPanel, {
      paddingSize: "s"
    }, /*#__PURE__*/React.createElement(EuiTitle, {
      size: "xs"
    }, /*#__PURE__*/React.createElement("h3", null, "Y-axis")), /*#__PURE__*/React.createElement(EuiSpacer, {
      size: "s"
    }), /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Position"
    }, /*#__PURE__*/React.createElement(EuiSelect, {
      options: yAxisPositionOptions,
      value: stateParams.yAxisPosition,
      onChange: function onChange(e) {
        return setValue('yAxisPosition', e.target.value);
      }
    })), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
      margin: "m"
    }), /*#__PURE__*/React.createElement(EuiFormRow, null, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Show axis lines and labels",
      checked: stateParams.yAxisShow,
      onChange: function onChange(e) {
        return setValue('yAxisShow', e.target.checked);
      }
    })), stateParams.yAxisShow ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Title"
    }, /*#__PURE__*/React.createElement(EuiFieldText, {
      placeholder: "Title",
      value: stateParams.yAxisTitle,
      onChange: function onChange(e) {
        return setValue('yAxisTitle', e.target.value);
      }
    })), /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Labels"
    }, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Show labels",
      checked: stateParams.yAxisShowLabels,
      onChange: function onChange(e) {
        return setValue('yAxisShowLabels', e.target.checked);
      }
    }))) : null);
  };

  var renderXAxisOptions = function renderXAxisOptions() {
    return /*#__PURE__*/React.createElement(EuiPanel, {
      paddingSize: "s"
    }, /*#__PURE__*/React.createElement(EuiTitle, {
      size: "xs"
    }, /*#__PURE__*/React.createElement("h3", null, "X-axis")), /*#__PURE__*/React.createElement(EuiSpacer, {
      size: "s"
    }), /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Position"
    }, /*#__PURE__*/React.createElement(EuiSelect, {
      options: xAxisPositionOptions,
      value: stateParams.xAxisPosition,
      onChange: function onChange(e) {
        return setValue('xAxisPosition', e.target.value);
      }
    })), /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Scale type"
    }, /*#__PURE__*/React.createElement(EuiSelect, {
      options: axisTypeOptions,
      value: stateParams.xAxisType,
      onChange: function onChange(e) {
        return setValue('xAxisType', e.target.value);
      }
    })), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
      margin: "m"
    }), /*#__PURE__*/React.createElement(EuiFormRow, null, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Show axis lines and labels",
      checked: stateParams.xAxisShow,
      onChange: function onChange(e) {
        return setValue('xAxisShow', e.target.checked);
      }
    })), stateParams.xAxisShow ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Title"
    }, /*#__PURE__*/React.createElement(EuiFieldText, {
      placeholder: "Title",
      value: stateParams.xAxisTitle,
      onChange: function onChange(e) {
        return setValue('xAxisTitle', e.target.value);
      }
    })), /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Labels"
    }, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Show labels",
      checked: stateParams.xAxisShowLabels,
      onChange: function onChange(e) {
        return setValue('xAxisShowLabels', e.target.checked);
      }
    }))) : null);
  };

  return /*#__PURE__*/React.createElement(React.Fragment, null, renderYAxisOptions(), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), renderXAxisOptions());
}
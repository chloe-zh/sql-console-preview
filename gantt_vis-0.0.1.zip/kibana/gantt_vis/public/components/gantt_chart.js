function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
import _ from 'lodash';
import React, { Fragment } from 'react';
import Plot from 'react-plotly.js';
export function GanttChart(_ref) {
  var config = _ref.config,
      vis = _ref.vis,
      visData = _ref.visData,
      visParams = _ref.visParams;

  var getGanttData = function getGanttData() {
    var source = visData.source;
    var data = [];
    if (source.length === 0) return data;
    var getStartTime = typeof _.get(source[0], visParams.startTimeField) === 'string' ? function (document) {
      return Date.parse(_.get(document, visParams.startTimeField));
    } : function (document) {
      return _.get(document, visParams.startTimeField);
    }; // source is ordered by startTimeField desc, last trace is the earliest trace and should start at 0

    var minStartTime = getStartTime(source[source.length - 1]);
    source.forEach(function (document) {
      var rawStartTime = getStartTime(document);
      var startTime = rawStartTime - minStartTime;

      var duration = _.get(document, visParams.durationField);

      var label = _.get(document, visParams.labelField);

      var rest = visParams.useDefaultColors ? {} : {
        marker: {
          color: visParams.colors
        }
      };
      data.push({
        x: [startTime],
        y: [label],
        type: 'bar',
        orientation: 'h',
        width: 0.4,
        marker: {
          color: 'rgba(0, 0, 0, 0)'
        },
        hoverinfo: 'none',
        showlegend: false
      }, _objectSpread({
        x: [duration],
        y: [label],
        type: 'bar',
        orientation: 'h',
        width: 0.4,
        name: label,
        text: [duration],
        hovertemplate: '%{text}<extra></extra>'
      }, rest));
    });
    return data;
  };

  var ganttData = getGanttData();
  return /*#__PURE__*/React.createElement(Fragment, null, visParams.labelField && visParams.startTimeField && visParams.durationField ? /*#__PURE__*/React.createElement(Plot, {
    data: ganttData,
    style: {
      width: '100%',
      height: '100%'
    },
    config: {
      displayModeBar: false
    },
    layout: {
      height: ganttData.length * 30 + 80,
      autosize: true,
      barmode: 'stack',
      // margin: {
      //   l: 80,
      //   r: 10,
      //   b: 30,
      //   t: 10,
      //   pad: 4,
      // },
      margin: {
        t: 30,
        l: 150
      },
      showlegend: visParams.showLegend,
      legend: {
        orientation: visParams.legendOrientation,
        traceorder: 'normal'
      },
      xaxis: {
        side: visParams.xAxisPosition,
        title: visParams.xAxisTitle,
        type: visParams.xAxisType,
        visible: visParams.xAxisShow,
        showticklabels: visParams.xAxisShowLabels,
        showgrid: visParams.xAxisShowGrid
      },
      yaxis: {
        side: visParams.yAxisPosition,
        title: visParams.yAxisTitle,
        type: 'category',
        visible: visParams.yAxisShow,
        showticklabels: visParams.yAxisShowLabels,
        showgrid: visParams.yAxisShowGrid
      }
    }
  }) : null);
}
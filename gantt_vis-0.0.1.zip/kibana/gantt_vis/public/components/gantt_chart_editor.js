/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
import { EuiFieldNumber, EuiFlexGroup, EuiFlexItem, EuiSpacer, EuiSuperSelect, EuiText } from '@elastic/eui';
import React from 'react';
export function GanttChartEditor(_ref) {
  var aggs = _ref.aggs,
      stateParams = _ref.stateParams,
      setValue = _ref.setValue;
  var fieldOptions = aggs.indexPattern.fields.map(function (field) {
    return {
      value: field.name,
      inputDisplay: field.name
    };
  });

  var createFieldSelect = function createFieldSelect(fieldName, displayName) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
      alignItems: "center",
      gutterSize: "none"
    }, /*#__PURE__*/React.createElement(EuiFlexItem, {
      grow: false,
      style: {
        width: 80
      }
    }, /*#__PURE__*/React.createElement(EuiText, null, displayName)), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiSuperSelect, {
      options: fieldOptions,
      valueOfSelected: stateParams[fieldName],
      onChange: function onChange(value) {
        return setValue(fieldName, value);
      }
    }))), /*#__PURE__*/React.createElement(EuiSpacer, null));
  };

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center",
    gutterSize: "none"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false,
    style: {
      width: 80
    }
  }, /*#__PURE__*/React.createElement(EuiText, null, "Size")), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiFieldNumber, {
    value: stateParams.size,
    onChange: function onChange(e) {
      return setValue('size', parseInt(e.target.value, 10));
    }
  }))), /*#__PURE__*/React.createElement(EuiSpacer, null), createFieldSelect('labelField', 'Label'), createFieldSelect('startTimeField', 'Start time'), createFieldSelect('durationField', 'Duration'));
}
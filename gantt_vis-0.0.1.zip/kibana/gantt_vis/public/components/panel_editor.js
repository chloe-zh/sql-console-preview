/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
import { EuiColorPicker, EuiFormRow, EuiPanel, EuiSelect, EuiSpacer, EuiSwitch, EuiTitle } from '@elastic/eui';
import React from 'react';
export function PanelEditor(_ref) {
  var aggs = _ref.aggs,
      stateParams = _ref.stateParams,
      setValue = _ref.setValue;
  var legendOrientationOptions = [{
    value: 'v',
    text: 'Vertical'
  }, {
    value: 'h',
    text: 'Horizontal'
  }];

  var renderLegendOptions = function renderLegendOptions() {
    return /*#__PURE__*/React.createElement(EuiPanel, {
      paddingSize: "s"
    }, /*#__PURE__*/React.createElement(EuiTitle, {
      size: "xs"
    }, /*#__PURE__*/React.createElement("h3", null, "Settings")), /*#__PURE__*/React.createElement(EuiSpacer, {
      size: "s"
    }), /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Legend orientation"
    }, /*#__PURE__*/React.createElement(EuiSelect, {
      options: legendOrientationOptions,
      value: stateParams.legendOrientation,
      onChange: function onChange(e) {
        return setValue('legendOrientation', e.target.value);
      },
      disabled: !stateParams.showLegend
    })), /*#__PURE__*/React.createElement(EuiFormRow, null, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Show legend",
      checked: stateParams.showLegend,
      onChange: function onChange(e) {
        return setValue('showLegend', e.target.checked);
      }
    })));
  };

  var renderGridOptions = function renderGridOptions() {
    return /*#__PURE__*/React.createElement(EuiPanel, {
      paddingSize: "s"
    }, /*#__PURE__*/React.createElement(EuiTitle, {
      size: "xs"
    }, /*#__PURE__*/React.createElement("h3", null, "Grid")), /*#__PURE__*/React.createElement(EuiSpacer, {
      size: "s"
    }), /*#__PURE__*/React.createElement(EuiFormRow, null, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Show X-axis lines",
      checked: stateParams.xAxisShowGrid,
      onChange: function onChange(e) {
        return setValue('xAxisShowGrid', e.target.checked);
      }
    })), /*#__PURE__*/React.createElement(EuiFormRow, null, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Show Y-axis lines",
      checked: stateParams.yAxisShowGrid,
      onChange: function onChange(e) {
        return setValue('yAxisShowGrid', e.target.checked);
      }
    })));
  };

  var renderColorOptions = function renderColorOptions() {
    return /*#__PURE__*/React.createElement(EuiPanel, {
      paddingSize: "s"
    }, /*#__PURE__*/React.createElement(EuiTitle, {
      size: "xs"
    }, /*#__PURE__*/React.createElement("h3", null, "Colors")), /*#__PURE__*/React.createElement(EuiSpacer, {
      size: "s"
    }), /*#__PURE__*/React.createElement(EuiFormRow, null, /*#__PURE__*/React.createElement(EuiSwitch, {
      label: "Use default colors",
      checked: stateParams.useDefaultColors,
      onChange: function onChange(e) {
        return setValue('useDefaultColors', e.target.checked);
      }
    })), /*#__PURE__*/React.createElement(EuiFormRow, {
      label: "Color"
    }, /*#__PURE__*/React.createElement(EuiColorPicker, {
      color: stateParams.colors,
      onChange: function onChange(e) {
        return setValue('colors', e);
      },
      disabled: stateParams.useDefaultColors
    })));
  };

  return /*#__PURE__*/React.createElement(React.Fragment, null, renderLegendOptions(), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), renderGridOptions(), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), renderColorOptions());
}
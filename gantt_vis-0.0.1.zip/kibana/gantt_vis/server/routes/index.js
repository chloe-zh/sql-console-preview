"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _configSchema = require("@kbn/config-schema");

/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
function defineRoutes(router) {
  router.post({
    path: '/api/gantt_vis/query',
    validate: {
      body: _configSchema.schema.object({
        index: _configSchema.schema.string(),
        size: _configSchema.schema.number(),
        body: _configSchema.schema.object({
          query: _configSchema.schema.maybe(_configSchema.schema.object({
            bool: _configSchema.schema.object({
              filter: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.object({}, {
                unknowns: 'allow'
              }))),
              must: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.object({}, {
                unknowns: 'allow'
              }))),
              should: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.object({}, {
                unknowns: 'allow'
              }))),
              must_not: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.object({}, {
                unknowns: 'allow'
              })))
            })
          })),
          sort: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.any()))
        })
      })
    }
  }, async (context, request, response) => {
    const {
      index,
      size,
      ...rest
    } = request.body;
    const params = {
      index,
      size,
      ...rest
    };

    try {
      const resp = await context.core.elasticsearch.legacy.client.callAsInternalUser('search', params);
      return response.ok({
        body: {
          total: resp.hits.total.value,
          hits: resp.hits.hits
        }
      });
    } catch (error) {
      console.error(error);
      return response.custom({
        statusCode: error.statusCode || 500,
        body: error.message
      });
    }
  });
}
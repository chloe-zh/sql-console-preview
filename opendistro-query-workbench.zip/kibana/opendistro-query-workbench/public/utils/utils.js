"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getQueryIndex = getQueryIndex;
exports.getDefaultTabId = getDefaultTabId;
exports.getDefaultTabLabel = getDefaultTabLabel;
exports.getSelectedResults = getSelectedResults;
exports.isEmpty = isEmpty;
exports.capitalizeFirstLetter = capitalizeFirstLetter;
exports.getMessageString = getMessageString;
exports.scrollToNode = scrollToNode;
exports.onDownloadFile = onDownloadFile;
exports.createRowTree = createRowTree;
exports.getRowTree = getRowTree;
exports.findRootNode = findRootNode;
exports.needsScrolling = needsScrolling;
exports.Node = exports.Tree = exports.getQueries = void 0;

var _typeof2 = _interopRequireDefault(require("@babel/runtime/helpers/typeof"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _constants = require("./constants");

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
// It returns an array of queries
var getQueries = function getQueries(queriesString) {
  if (queriesString == '') {
    return [];
  }

  return queriesString.split(';').map(function (query) {
    return query.trim();
  }).filter(function (query) {
    return query != '';
  });
}; // It retrieves the index from the query. The index is used to label the query results tab


exports.getQueries = getQueries;

function getQueryIndex(query) {
  if (query) {
    var queryFrom = query.toLowerCase().split("from");

    if (queryFrom.length > 1) {
      return queryFrom[1].split(" ")[1];
    }
  }

  return query;
} // Tabs utils


function getDefaultTabId(queryResults) {
  return queryResults && queryResults.length > 0 && queryResults[0].fulfilled ? "0" : _constants.MESSAGE_TAB_LABEL;
}

function getDefaultTabLabel(queryResults, queryString) {
  return queryResults && queryResults.length > 0 && queryResults[0].fulfilled ? getQueryIndex(queryString) : _constants.MESSAGE_TAB_LABEL;
} // It returns the results for the selected tab


function getSelectedResults(results, selectedTabId) {
  var selectedIndex = parseInt(selectedTabId);

  if (!Number.isNaN(selectedIndex) && results) {
    var selectedResult = results[selectedIndex];
    return selectedResult && selectedResult.fulfilled ? selectedResult.data : undefined;
  }

  return undefined;
}

function isEmpty(obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      return false;
    }
  }

  return true;
}

function capitalizeFirstLetter(name) {
  return name && name.length > 0 ? name.charAt(0).toUpperCase() + name.slice(1) : name;
}

function getMessageString(messages, tabNames) {
  return messages && messages.length > 0 && tabNames && tabNames.length > 0 ? messages.reduce(function (finalMessage, message, currentIndex) {
    return finalMessage.concat(capitalizeFirstLetter(tabNames[currentIndex]), ': ', messages[currentIndex].text, '\n\n');
  }, '') : '';
}

function scrollToNode(nodeId) {
  var element = document.getElementById(nodeId);

  if (element) {
    element.scrollIntoView();
  }
} // Download functions


function onDownloadFile(data, fileFormat, fileName) {
  var encodedUri = encodeURI(data);
  var content = 'data:text/' + fileFormat + ';charset=utf-8,' + encodedUri;
  var link = document.createElement("a");
  link.setAttribute('href', content);
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

var Tree = function Tree(data, rootId) {
  (0, _classCallCheck2.default)(this, Tree);
  (0, _defineProperty2.default)(this, "_root", void 0);
  this._root = new Node(data, rootId, '', this._root);
};

exports.Tree = Tree;

var Node = function Node(data, parentId) {
  var name = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  var parent = arguments.length > 3 ? arguments[3] : undefined;
  (0, _classCallCheck2.default)(this, Node);
  (0, _defineProperty2.default)(this, "data", void 0);
  (0, _defineProperty2.default)(this, "name", void 0);
  (0, _defineProperty2.default)(this, "children", void 0);
  (0, _defineProperty2.default)(this, "parent", void 0);
  (0, _defineProperty2.default)(this, "nodeId", void 0);
  this.data = data;
  this.name = name;
  this.children = [];
  this.parent = parent;
  this.nodeId = name === '' ? parentId : parentId + '_' + name;
}; // It creates a tree of nested objects or arrays for the row, where rootId is the rowId and item is the field value


exports.Node = Node;

function createRowTree(item, rootId) {
  var tree = new Tree(item, rootId);
  var root = tree._root;

  if ((0, _typeof2.default)(item) === 'object') {
    for (var j = 0; j < Object.keys(item).length; j++) {
      var itemKey = Object.keys(item)[j];
      var data = item[itemKey]; // If value of field is an array or an object it gets added to the tree

      if (data !== null && (Array.isArray(data) || (0, _typeof2.default)(data) === 'object')) {
        var firstNode = new Node(data, rootId, itemKey, root);
        root.children.push(firstNode);
      }
    }
  }

  return tree;
} // It returns the tree for the given nodeId if it exists or create a new one otherwise


function getRowTree(nodeId, item, expandedRowMap) {
  return expandedRowMap[nodeId] && expandedRowMap[nodeId].nodes ? expandedRowMap[nodeId].nodes : createRowTree(item, nodeId);
}

function findRootNode(node, expandedRowMap) {
  var rootNodeId = node.nodeId.split('_')[0];
  return expandedRowMap[rootNodeId].nodes._root;
}
/********* TABS Functions *********/
//It checks if an element needs a scrolling


function needsScrolling(elementId) {
  var element = document.getElementById(elementId);

  if (element === null) {
    return false;
  }

  return element.scrollWidth > element.offsetWidth;
}
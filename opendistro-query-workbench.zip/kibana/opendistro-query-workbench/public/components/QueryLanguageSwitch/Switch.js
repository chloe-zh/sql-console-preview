"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var toggleButtons = [{
  id: 'SQL',
  label: 'SQL'
}, {
  id: 'PPL',
  label: 'PPL'
}];

var Switch = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(Switch, _React$Component);

  var _super = _createSuper(Switch);

  function Switch(props) {
    var _this;

    (0, _classCallCheck2.default)(this, Switch);
    _this = _super.call(this, props);
    _this.state = {
      language: 'SQL'
    };
    return _this;
  }

  (0, _createClass2.default)(Switch, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      return /*#__PURE__*/_react.default.createElement(_eui.EuiButtonGroup, {
        className: "query-language-switch",
        legend: "query-language-swtich",
        options: toggleButtons,
        onChange: function onChange(id) {
          return _this2.props.onChange(id);
        },
        idSelected: this.props.language,
        color: "primary"
      });
    }
  }]);
  return Switch;
}(_react.default.Component);

var _default = Switch;
exports.default = _default;
module.exports = exports.default;
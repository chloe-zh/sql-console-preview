export const PLUGIN_ID = 'traceAnalytics';
export const PLUGIN_NAME = 'Trace Analytics';

export const INDEX_NAME = 'otel-v1-apm-span-000001';
export const DATE_FORMAT = 'MM/DD/YYYY HH:mm:ss';

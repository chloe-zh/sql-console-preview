"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ROUTE_PATH_PPL_TEXT = exports.ROUTE_PATH_SQL_TEXT = exports.ROUTE_PATH_PPL_JSON = exports.ROUTE_PATH_SQL_JSON = exports.ROUTE_PATH_PPL_CSV = exports.ROUTE_PATH_SQL_CSV = exports.ROUTE_PATH_QUERY_CSV = exports.ROUTE_PATH_PPL_QUERY = exports.ROUTE_PATH_SQL_QUERY = void 0;

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
var ROUTE_PATH_SQL_QUERY = '/api/sql_console/sqlquery';
exports.ROUTE_PATH_SQL_QUERY = ROUTE_PATH_SQL_QUERY;
var ROUTE_PATH_PPL_QUERY = '/api/sql_console/pplquery';
exports.ROUTE_PATH_PPL_QUERY = ROUTE_PATH_PPL_QUERY;
var ROUTE_PATH_QUERY_CSV = '/api/sql_console/querycsv';
exports.ROUTE_PATH_QUERY_CSV = ROUTE_PATH_QUERY_CSV;
var ROUTE_PATH_SQL_CSV = '/api/sql_console/sqlcsv';
exports.ROUTE_PATH_SQL_CSV = ROUTE_PATH_SQL_CSV;
var ROUTE_PATH_PPL_CSV = '/api/sql_console/pplcsv';
exports.ROUTE_PATH_PPL_CSV = ROUTE_PATH_PPL_CSV;
var ROUTE_PATH_SQL_JSON = '/api/sql_console/sqljson';
exports.ROUTE_PATH_SQL_JSON = ROUTE_PATH_SQL_JSON;
var ROUTE_PATH_PPL_JSON = '/api/sql_console/ppljson';
exports.ROUTE_PATH_PPL_JSON = ROUTE_PATH_PPL_JSON;
var ROUTE_PATH_SQL_TEXT = '/api/sql_console/sqltext';
exports.ROUTE_PATH_SQL_TEXT = ROUTE_PATH_SQL_TEXT;
var ROUTE_PATH_PPL_TEXT = '/api/sql_console/ppltext';
exports.ROUTE_PATH_PPL_TEXT = ROUTE_PATH_PPL_TEXT;
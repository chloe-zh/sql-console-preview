"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PPLPage = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var PPLPage = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(PPLPage, _React$Component);

  var _super = _createSuper(PPLPage);

  function PPLPage(props) {
    var _this;

    (0, _classCallCheck2.default)(this, PPLPage);
    _this = _super.call(this, props);
    _this.state = {
      pplQuery: _this.props.pplQuery,
      translation: "",
      isModalVisible: false
    };
    return _this;
  }

  (0, _createClass2.default)(PPLPage, [{
    key: "setIsModalVisible",
    value: function setIsModalVisible(visible) {
      this.setState({
        isModalVisible: visible
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var closeModal = function closeModal() {
        return _this2.setIsModalVisible(false);
      };

      var showModal = function showModal() {
        return _this2.setIsModalVisible(true);
      };

      var modal;

      if (this.state.isModalVisible) {
        modal = /*#__PURE__*/_react.default.createElement(_eui.EuiOverlayMask, {
          onClick: closeModal
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiModal, {
          onClose: closeModal
        }, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeader, null, /*#__PURE__*/_react.default.createElement(_eui.EuiModalHeaderTitle, null, "Explain")), /*#__PURE__*/_react.default.createElement(_eui.EuiModalBody, null, /*#__PURE__*/_react.default.createElement(_eui.EuiCodeBlock, {
          language: "json",
          fontSize: "m",
          isCopyable: true
        }, this.props.pplTranslations.map(function (queryTranslation) {
          return JSON.stringify(queryTranslation.data, null, 2);
        }).join("\n"))), /*#__PURE__*/_react.default.createElement(_eui.EuiModalFooter, null, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
          onClick: closeModal,
          fill: true
        }, "Close"))));
      }

      return /*#__PURE__*/_react.default.createElement(_eui.EuiPanel, {
        className: "ppl-query-editor container-panel",
        paddingSize: "none"
      }, /*#__PURE__*/_react.default.createElement("div", {
        className: "sql-console-query-editor"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiPanel, {
        className: "sql-query-editor container-panel",
        paddingSize: "none"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiText, {
        className: "sql-query-panel-header"
      }, "Query Editor"), /*#__PURE__*/_react.default.createElement(_eui.EuiCodeEditor, {
        mode: "sql",
        theme: "sql_console",
        width: "100%",
        height: "15rem",
        value: this.props.pplQuery,
        onChange: this.props.updatePPLQueries,
        showPrintMargin: false,
        setOptions: {
          fontSize: "12px",
          enableBasicAutocompletion: true,
          enableSnippets: true,
          enableLiveAutocompletion: true
        },
        "aria-label": "Code Editor"
      }))), /*#__PURE__*/_react.default.createElement("div", null, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
        className: "action-container",
        gutterSize: "m"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        className: "sql-editor-buttons",
        grow: false,
        onClick: function onClick() {
          return _this2.props.onRun(_this2.props.pplQuery);
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        fill: true,
        className: "sql-editor-button"
      }, "Run")), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false,
        onClick: function onClick() {
          _this2.props.updatePPLQueries("");

          _this2.props.onClear();
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        className: "sql-editor-button"
      }, "Clear")), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false,
        onClick: function onClick() {
          return _this2.props.onTranslate(_this2.props.pplQuery);
        }
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiButton, {
        className: "sql-editor-button",
        onClick: showModal
      }, "Explain"), modal))));
    }
  }]);
  return PPLPage;
}(_react.default.Component);

exports.PPLPage = PPLPage;
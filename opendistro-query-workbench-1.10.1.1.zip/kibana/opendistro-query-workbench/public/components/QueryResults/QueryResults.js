"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _assertThisInitialized2 = _interopRequireDefault(require("@babel/runtime/helpers/assertThisInitialized"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireDefault(require("react"));

var _services = require("@elastic/eui/lib/services");

var _eui = require("@elastic/eui");

var _QueryResultsBody = _interopRequireDefault(require("./QueryResultsBody"));

var _utils = require("../../utils/utils");

var _constants = require("../../utils/constants");

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

var QueryResults = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(QueryResults, _React$Component);

  var _super = _createSuper(QueryResults);

  function QueryResults(props) {
    var _this;

    (0, _classCallCheck2.default)(this, QueryResults);
    _this = _super.call(this, props);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "sortableColumns", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "sortableProperties", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "sortedColumn", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "tabNames", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "pager", void 0);
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "showTabsMenu", function () {
      _this.setState(function (prevState) {
        return {
          isPopoverOpen: !prevState.isPopoverOpen
        };
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "slideTabsRight", function () {
      if (document.getElementById(_constants.TAB_CONTAINER_ID)) {
        document.getElementById(_constants.TAB_CONTAINER_ID).scrollBy(50, 0);
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "slideTabsLeft", function () {
      if (document.getElementById(_constants.TAB_CONTAINER_ID)) {
        document.getElementById(_constants.TAB_CONTAINER_ID).scrollBy(-50, 0);
      }
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "closePopover", function () {
      _this.setState({
        isPopoverOpen: false
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangeItemsPerPage", function (itemsPerPage) {
      _this.pager.setItemsPerPage(itemsPerPage);

      _this.setState({
        itemsPerPage: itemsPerPage
      });
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onChangePage", function (pageIndex) {
      _this.pager.goToPageIndex(pageIndex);

      _this.setState({});
    });
    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this), "onSort", function (prop) {
      _this.sortableProperties.sortOn(prop);

      _this.sortedColumn = prop;

      _this.setState({});
    });
    _this.state = {
      isPopoverOpen: false,
      tabsOverflow: _this.props.tabsOverflow ? _this.props.tabsOverflow : false,
      itemsPerPage: _constants.DEFAULT_NUM_RECORDS_PER_PAGE
    };
    _this.sortableColumns = [];
    _this.sortedColumn = "";
    _this.sortableProperties = new _services.SortableProperties([{
      name: "",
      getValue: function getValue(item) {
        return "";
      },
      isAscending: true
    }], "");
    _this.tabNames = [];
    _this.pager = new _eui.Pager(0, _this.state.itemsPerPage);
    return _this;
  }

  (0, _createClass2.default)(QueryResults, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var showArrow = (0, _utils.needsScrolling)("tabsContainer");

      if (showArrow !== this.state.tabsOverflow) {
        this.setState({
          tabsOverflow: showArrow
        });
      }
    } // Actions for Tabs Button

  }, {
    key: "updatePagination",
    value: function updatePagination(totalItemsCount) {
      this.pager.setTotalItems(totalItemsCount);
    } // Update SORTABLE COLUMNS - All columns

  }, {
    key: "updateSortableColumns",
    value: function updateSortableColumns(queryResultsSelected) {
      var _this2 = this;

      if (this.sortableColumns.length === 0) {
        queryResultsSelected.fields.map(function (field) {
          _this2.sortableColumns.push({
            name: field,
            getValue: function getValue(item) {
              return item[field];
            },
            isAscending: true
          });
        });
        this.sortedColumn = this.sortableColumns.length > 0 ? this.sortableColumns[0].name : "";
        this.sortableProperties = new _services.SortableProperties(this.sortableColumns, this.sortedColumn);
      }
    }
  }, {
    key: "renderTabs",
    value: function renderTabs() {
      var tabs = [{
        id: _constants.MESSAGE_TAB_LABEL,
        name: _constants.MESSAGE_TAB_LABEL,
        disabled: false
      }];
      this.tabNames = [];

      if (this.props.queryResults) {
        for (var i = 0; i < this.props.queryResults.length; i += 1) {
          var tabName = (0, _utils.getQueryIndex)(this.props.queries[i]);
          this.tabNames.push(tabName);

          if (this.props.queryResults[i].fulfilled) {
            tabs.push({
              id: i.toString(),
              name: tabName,
              disabled: false
            });
          }
        }
      }

      return tabs;
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      // Update PAGINATION and SORTABLE columns
      var queryResultSelected = (0, _utils.getSelectedResults)(this.props.queryResults, this.props.selectedTabId);

      if (queryResultSelected) {
        var matchingItems = this.props.searchQuery ? _eui.EuiSearchBar.Query.execute(this.props.searchQuery, queryResultSelected.records) : queryResultSelected.records;
        this.updatePagination(matchingItems.length);
        this.updateSortableColumns(queryResultSelected);
      } // Action button with list of tabs, TODO: disable tabArrowRight and tabArrowLeft when no more scrolling is possible


      var tabArrowDown = /*#__PURE__*/_react.default.createElement(_eui.EuiIcon, {
        onClick: this.showTabsMenu,
        type: "arrowDown"
      });

      var tabArrowRight = /*#__PURE__*/_react.default.createElement(_eui.EuiIcon, {
        onClick: this.slideTabsRight,
        type: "arrowRight"
      });

      var tabArrowLeft = /*#__PURE__*/_react.default.createElement(_eui.EuiIcon, {
        onClick: this.slideTabsLeft,
        "data-test-subj": "slide-left",
        type: "arrowLeft"
      });

      var tabs = this.renderTabs();
      var tabsItems = tabs.map(function (tab, index) {
        return /*#__PURE__*/_react.default.createElement(_eui.EuiContextMenuItem, {
          key: "10 rows",
          icon: "empty",
          onClick: function onClick() {
            _this3.closePopover();

            _this3.pager.goToPageIndex(0);

            _this3.sortableColumns = [];

            _this3.props.onSelectedTabIdChange(tab);
          }
        }, tab.name);
      });
      var tabsButtons = tabs.map(function (tab, index) {
        return /*#__PURE__*/_react.default.createElement(_eui.EuiTab, {
          onClick: function onClick() {
            _this3.pager.goToPageIndex(0);

            _this3.sortableColumns = [];

            _this3.props.onSelectedTabIdChange(tab);
          },
          isSelected: tab.id === _this3.props.selectedTabId,
          disabled: tab.disabled,
          key: index
        }, tab.name);
      });
      return /*#__PURE__*/_react.default.createElement(_eui.EuiPanel, {
        className: "query-result-container",
        paddingSize: "none"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
        style: {
          padding: "10px"
        }
      }, this.state.tabsOverflow && /*#__PURE__*/_react.default.createElement("div", {
        className: "tab-arrow-down-container"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiPopover, {
        button: tabArrowLeft,
        "data-test-subj": "slide-left"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiContextMenuPanel, {
        items: tabsItems
      })))), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, {
        className: "tabs-container",
        alignItems: "center",
        gutterSize: "s",
        id: "tabsContainer"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        style: {
          marginTop: "8px",
          marginBottom: "18px"
        },
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiTabs, null, tabsButtons))), this.state.tabsOverflow && /*#__PURE__*/_react.default.createElement("div", {
        className: "tab-arrow-down-container"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexGroup, null, /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiPopover, {
        button: tabArrowRight,
        "data-test-subj": "slide-right"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiContextMenuPanel, {
        items: tabsItems
      }))), /*#__PURE__*/_react.default.createElement(_eui.EuiFlexItem, {
        grow: false
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiPopover, {
        id: "singlePanel",
        button: tabArrowDown,
        "data-test-subj": "slide-down",
        isOpen: this.state.isPopoverOpen,
        closePopover: this.closePopover,
        panelPaddingSize: "none",
        anchorPosition: "downLeft"
      }, /*#__PURE__*/_react.default.createElement(_eui.EuiContextMenuPanel, {
        items: tabsItems
      })))))), /*#__PURE__*/_react.default.createElement(_eui.EuiHorizontalRule, {
        margin: "none"
      }), /*#__PURE__*/_react.default.createElement(_QueryResultsBody.default, {
        language: this.props.language,
        queries: this.props.queries,
        selectedTabId: this.props.selectedTabId,
        selectedTabName: this.props.selectedTabName,
        tabNames: this.tabNames,
        queryResultSelected: queryResultSelected,
        queryResultsJSON: this.props.queryResultsJSON,
        queryResultsJDBC: this.props.queryResultsJDBC,
        queryResultsCSV: this.props.queryResultsCSV,
        queryResultsTEXT: this.props.queryResultsTEXT,
        messages: this.props.messages,
        searchQuery: this.props.searchQuery,
        onQueryChange: this.props.onQueryChange,
        pager: this.pager,
        itemsPerPage: this.state.itemsPerPage,
        firstItemIndex: this.pager.getFirstItemIndex(),
        lastItemIndex: this.pager.getLastItemIndex(),
        onChangeItemsPerPage: this.onChangeItemsPerPage,
        onChangePage: this.onChangePage,
        onSort: this.onSort,
        sortedColumn: this.sortedColumn,
        sortableProperties: this.sortableProperties,
        itemIdToExpandedRowMap: this.props.itemIdToExpandedRowMap,
        updateExpandedMap: this.props.updateExpandedMap,
        getJson: this.props.getJson,
        getJdbc: this.props.getJdbc,
        getCsv: this.props.getCsv,
        getText: this.props.getText
      }));
    }
  }]);
  return QueryResults;
}(_react.default.Component);

var _default = QueryResults;
exports.default = _default;
module.exports = exports.default;
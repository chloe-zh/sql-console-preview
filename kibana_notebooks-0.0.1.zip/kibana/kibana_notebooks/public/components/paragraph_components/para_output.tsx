/*
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

import React from 'react';
import { Outputs } from '@nteract/presentational-components';
import { Media } from '@nteract/outputs';
import MarkdownRender from '@nteract/markdown';
import { EuiText } from '@elastic/eui';

import { DATE_FORMAT, ParaType } from '../../../common';
import { DashboardContainerInput, DashboardStart } from '../../../../../src/plugins/dashboard/public';
import moment from 'moment';

/*
 * "ParaOutput" component is used by notebook to populate paragraph outputs for an open notebook.
 *
 * Props taken in as params are:
 * para - parsed paragraph from notebook
 *
 * Outputs component of nteract used as a container for notebook UI.
 * https://components.nteract.io/#outputs
 */
export const ParaOutput = (props: {
  para: ParaType;
  visInput: DashboardContainerInput;
  setVisInput: (input: DashboardContainerInput) => void;
  DashboardContainerByValueRenderer: DashboardStart['DashboardContainerByValueRenderer'];
}) => {
  const outputBody = (key: string, typeOut: string, val: string) => {
    /* Returns a component to render paragraph outputs using the para.typeOut property
     * Currently supports HTML, TABLE, IMG
     * TODO: add table rendering
     */

    if (typeOut !== undefined) {
      switch (typeOut) {
        case 'MARKDOWN':
          return (
            <EuiText key={key} className='markdown-output-text'>
              <MarkdownRender source={val} />
            </EuiText>
          );
        case 'VISUALIZATION':
          let from = moment(visInput?.timeRange?.from).format(DATE_FORMAT);
          let to = moment(visInput?.timeRange?.to).format(DATE_FORMAT);
          from = from === 'Invalid date' ? visInput.timeRange.from : from;
          to = to === 'Invalid date' ? visInput.timeRange.to : to;
          return (
            <>
              <EuiText size='s' style={{ marginLeft: 9 }}>
                {`${from} - ${to}`}
              </EuiText>
              <DashboardContainerByValueRenderer key={key} input={visInput} onInputUpdated={setVisInput} />
            </>
          );
        case 'HTML':
          return (
            <EuiText key={key}>
              <Media.HTML data={val} />
            </EuiText>
          );
        case 'TABLE':
          return <pre key={key}>{val}</pre>;
        case 'IMG':
          return <img alt="" src={'data:image/gif;base64,' + val} key={key} />;
        default:
          return <pre key={key}>{val}</pre>;
      }
    } else {
      console.log('output not supported', typeOut);
      return <pre />;
    }
  };

  const { para, DashboardContainerByValueRenderer, visInput, setVisInput } = props;

  return (
    <Outputs hidden={para.isOutputHidden}>
      {para.typeOut.map((typeOut: string, tIdx: number) =>
        outputBody(para.uniqueId + '_paraOutputBody', typeOut, para.out[tIdx])
      )}
    </Outputs>
  );
};
